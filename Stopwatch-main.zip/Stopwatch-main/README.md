# The Simplest Stopwatch for Android

Made especially for speedcubing, as you can tap anywhere to start/pause the stopwatch.

You can focus on your shuffled rubik's cube now xD

# Tested on 

SAMSUNG GALAXY J6 (SM-J600FN 10 API 29)

ALCATEL 1S (TCL 5024D_EEA 9.0 API 28)


# PRIVACY POLICY

This app does not collect any data. It's a simple open-source stopwatch application which everyone can use for free.

--------------------------------------------------------------------------------------------------------

<img src="https://i.imgur.com/Zt5yBid.jpg" width="360" height="740"> <img src="https://i.imgur.com/vIfbHUq.jpg" width="360" height="740">

![](https://i.imgur.com/sftUNxt.jpg)

# Play Store Download Link

https://play.google.com/store/apps/details?id=com.e.stopwatch
